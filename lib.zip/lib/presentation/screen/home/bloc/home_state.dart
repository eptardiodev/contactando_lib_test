part of 'home_bloc.dart';

enum HomeStatus { initial, loading, success, failure }

class HomeState extends Equatable {
  final HomeStatus status;
  final int selectedTab;

  const HomeState({
    this.status = HomeStatus.initial,
    this.selectedTab = 0,
  });

  HomeState copyWith({HomeStatus? status, int? selectedTab}) {
    return HomeState(
      status: status ?? this.status,
      selectedTab: selectedTab ?? this.selectedTab,
    );
  }

  @override
  List<Object?> get props => [status, selectedTab];

  @override
  bool get stringify => true;
}
