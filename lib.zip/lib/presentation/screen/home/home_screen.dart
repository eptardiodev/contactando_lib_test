import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:contactando_app_gs/presentation/screen/contacts/contacts_screen.dart';
import 'package:contactando_app_gs/presentation/screen/home/bloc/home_bloc.dart';

/// Pantalla principal de la aplicación.
///
/// Provee [HomeBloc] y sirve como shell para las secciones
/// de la app (Contactos, Transacciones, Dashboard).
/// Se integra al árbol de rutas existente en [HomeRoutes].
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => HomeBloc()..add(const HomeLoadEvent()),
      child: const _HomeView(),
    );
  }
}

class _HomeView extends StatefulWidget {
  const _HomeView();

  @override
  State<_HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<_HomeView> {
  int _selectedIndex = 0;

  static const List<Widget> _screens = [
    ContactsScreen(),
    _PlaceholderScreen(label: 'Transacciones'),
    _PlaceholderScreen(label: 'Dashboard'),
  ];

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeBloc, HomeState>(
      builder: (context, state) {
        if (state.status == HomeStatus.loading) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        return Scaffold(
          body: IndexedStack(
            index: _selectedIndex,
            children: _screens,
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (index) =>
                setState(() => _selectedIndex = index),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.people_outline),
                selectedIcon: Icon(Icons.people),
                label: 'Contactos',
              ),
              NavigationDestination(
                icon: Icon(Icons.monetization_on_outlined),
                selectedIcon: Icon(Icons.monetization_on),
                label: 'Transacciones',
              ),
              NavigationDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard),
                label: 'Dashboard',
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Placeholder para secciones aún no implementadas.
class _PlaceholderScreen extends StatelessWidget {
  final String label;

  const _PlaceholderScreen({required this.label});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(label)),
      body: Center(
        child: Text(
          '$label - próximamente',
          style: Theme.of(context).textTheme.titleLarge,
        ),
      ),
    );
  }
}
