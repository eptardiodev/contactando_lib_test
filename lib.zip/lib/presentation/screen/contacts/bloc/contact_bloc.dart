import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:contactando_app_gs/domain/contacts/contacts_model.dart';
import 'package:contactando_app_gs/domain/contacts/i_contact_repository.dart';

part 'contact_event.dart';
part 'contact_state.dart';

class ContactBloc extends Bloc<ContactEvent, ContactState> {
  final IContactRepository _repository;

  ContactBloc({required IContactRepository repository})
      : _repository = repository,
        super(const ContactState()) {
    on<ContactFetchEvent>(_onFetch);
    on<ContactSearchEvent>(_onSearch);
    on<ContactAddEvent>(_onAdd);
    on<ContactUpdateEvent>(_onUpdate);
    on<ContactDeleteEvent>(_onDelete);
  }

  FutureOr<void> _onFetch(
    ContactFetchEvent event,
    Emitter<ContactState> emit,
  ) async {
    emit(state.copyWith(status: ContactStatus.loading));
    try {
      final contacts = await _repository.getContactsByUser(event.usuarioId);
      emit(state.copyWith(
        contacts: contacts,
        status: ContactStatus.success,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ContactStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }

  FutureOr<void> _onSearch(
    ContactSearchEvent event,
    Emitter<ContactState> emit,
  ) async {
    emit(state.copyWith(status: ContactStatus.loading));
    try {
      final contacts =
          await _repository.searchContacts(event.usuarioId, event.query);
      emit(state.copyWith(
        contacts: contacts,
        status: ContactStatus.success,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ContactStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }

  FutureOr<void> _onAdd(
    ContactAddEvent event,
    Emitter<ContactState> emit,
  ) async {
    emit(state.copyWith(status: ContactStatus.loading));
    try {
      await _repository.addContact(event.contact);
      // Recarga la lista completa después de agregar
      final contacts =
          await _repository.getContactsByUser(event.contact.usuarioId);
      emit(state.copyWith(
        contacts: contacts,
        status: ContactStatus.success,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ContactStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }

  FutureOr<void> _onUpdate(
    ContactUpdateEvent event,
    Emitter<ContactState> emit,
  ) async {
    emit(state.copyWith(status: ContactStatus.loading));
    try {
      await _repository.updateContact(event.contact.id!, event.contact);
      final contacts =
          await _repository.getContactsByUser(event.contact.usuarioId);
      emit(state.copyWith(
        contacts: contacts,
        status: ContactStatus.success,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ContactStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }

  FutureOr<void> _onDelete(
    ContactDeleteEvent event,
    Emitter<ContactState> emit,
  ) async {
    emit(state.copyWith(status: ContactStatus.loading));
    try {
      await _repository.deleteContact(event.contact.id!);
      final contacts =
          await _repository.getContactsByUser(event.contact.usuarioId);
      emit(state.copyWith(
        contacts: contacts,
        status: ContactStatus.success,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ContactStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }
}
