part of 'add_contact_bloc.dart';

abstract class AddContactEvent extends Equatable {
  const AddContactEvent();

  @override
  List<Object?> get props => [];
}

class AddContactLoadDataEvent extends AddContactEvent {
  final String usuarioId;
  const AddContactLoadDataEvent(this.usuarioId);

  @override
  List<Object?> get props => [usuarioId];
}

class AddContactSubmitEvent extends AddContactEvent {
  final String usuarioId;
  final String nombre;
  final String telefono;
  final String? email;
  final String? foto;
  final String? notas;
  final String? direccion;
  final String? tarjeta;
  final String? pais;
  final String? relacion;

  const AddContactSubmitEvent({
    required this.usuarioId,
    required this.nombre,
    required this.telefono,
    this.email,
    this.foto,
    this.notas,
    this.direccion,
    this.tarjeta,
    this.pais,
    this.relacion,
  });

  @override
  List<Object?> get props => [
        usuarioId, nombre, telefono, email,
        foto, notas, direccion, tarjeta, pais, relacion,
      ];
}
