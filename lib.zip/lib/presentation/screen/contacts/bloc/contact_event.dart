part of 'contact_bloc.dart';

abstract class ContactEvent extends Equatable {
  const ContactEvent();

  @override
  List<Object?> get props => [];
}

class ContactFetchEvent extends ContactEvent {
  final String usuarioId;
  const ContactFetchEvent(this.usuarioId);

  @override
  List<Object?> get props => [usuarioId];
}

class ContactSearchEvent extends ContactEvent {
  final int usuarioId;
  final String query;
  const ContactSearchEvent({required this.usuarioId, required this.query});

  @override
  List<Object?> get props => [usuarioId, query];
}

class ContactAddEvent extends ContactEvent {
  final ContactModel contact;
  const ContactAddEvent(this.contact);

  @override
  List<Object?> get props => [contact];
}

class ContactUpdateEvent extends ContactEvent {
  final ContactModel contact;
  const ContactUpdateEvent(this.contact);

  @override
  List<Object?> get props => [contact];
}

class ContactDeleteEvent extends ContactEvent {
  final ContactModel contact;
  const ContactDeleteEvent(this.contact);

  @override
  List<Object?> get props => [contact];
}
