part of 'contact_bloc.dart';

enum ContactStatus { initial, loading, success, failure }

class ContactState extends Equatable {
  final List<ContactModel> contacts;
  final ContactStatus status;
  final String? errorMessage;

  const ContactState({
    this.contacts = const [],
    this.status = ContactStatus.initial,
    this.errorMessage,
  });

  ContactState copyWith({
    List<ContactModel>? contacts,
    ContactStatus? status,
    String? errorMessage,
  }) {
    return ContactState(
      contacts: contacts ?? this.contacts,
      status: status ?? this.status,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  List<Object?> get props => [contacts, status, errorMessage];

  @override
  bool get stringify => true;
}
