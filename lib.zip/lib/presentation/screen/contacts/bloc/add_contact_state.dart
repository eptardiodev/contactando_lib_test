part of 'add_contact_bloc.dart';

enum AddContactStatus { initial, loading, success, failure }

class AddContactState extends Equatable {
  final AddContactStatus status;
  final List<String> relaciones;
  final List<String> paises;
  final String? errorMessage;

  const AddContactState({
    this.status = AddContactStatus.initial,
    this.relaciones = const [],
    this.paises = const [],
    this.errorMessage,
  });

  AddContactState copyWith({
    AddContactStatus? status,
    List<String>? relaciones,
    List<String>? paises,
    String? errorMessage,
  }) {
    return AddContactState(
      status: status ?? this.status,
      relaciones: relaciones ?? this.relaciones,
      paises: paises ?? this.paises,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, relaciones, paises, errorMessage];

  @override
  bool get stringify => true;
}
