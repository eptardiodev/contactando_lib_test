import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:contactando_app_gs/data/api/contact_api.dart';
import 'package:contactando_app_gs/data/repository/contact_repository.dart';
import 'package:contactando_app_gs/domain/contacts/contacts_model.dart';
import 'package:contactando_app_gs/presentation/screen/contacts/bloc/contact_bloc.dart';
import 'package:contactando_app_gs/presentation/screen/contacts/add_contact_screen.dart';

/// Pantalla de lista de contactos.
///
/// Provee su propio [ContactBloc] y escucha cambios de estado
/// para mostrar la lista, loading o errores.
class ContactsScreen extends StatelessWidget {
  // TODO: reemplazar por el usuarioId real desde la sesión activa
  static const String _usuarioId = "272ecaa0-14d3-4c21-8893-a929afb1ced9";

  const ContactsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ContactBloc(
        repository: ContactRepository(ContactApi()),
      )..add(const ContactFetchEvent(_usuarioId)),
      child: const _ContactsView(),
    );
  }
}

class _ContactsView extends StatelessWidget {
  const _ContactsView();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context),
      body: _buildBody(context),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _buildFab(context),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      title: const Text(
        'Contactos',
        style: TextStyle(
          color: Colors.black,
          fontSize: 25,
          fontWeight: FontWeight.bold,
        ),
      ),
      actions: [
        IconButton(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          icon: Icon(Icons.search, color: Colors.grey.shade700, size: 30),
          onPressed: () => _onSearch(context),
        ),
      ],
    );
  }

  Widget _buildBody(BuildContext context) {
    return Column(
      children: [
        Divider(color: Colors.grey.shade300),
        const SizedBox(height: 6),
        Expanded(
          child: BlocConsumer<ContactBloc, ContactState>(
            listenWhen: (previous, current) =>
                current.status == ContactStatus.failure,
            listener: (context, state) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.errorMessage ?? 'Error desconocido'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            builder: (context, state) {
              if (state.status == ContactStatus.loading &&
                  state.contacts.isEmpty) {
                return const Center(child: CircularProgressIndicator());
              }
              if (state.contacts.isEmpty) {
                return const Center(child: Text('No hay contactos'));
              }
              return ListView.builder(
                itemCount: state.contacts.length,
                itemBuilder: (context, index) =>
                    _ContactCard(contact: state.contacts[index]),
              );
            },
          ),
        ),
      ],
    );
  }

  BottomNavigationBar _buildBottomNav() {
    return BottomNavigationBar(
      backgroundColor: Colors.white,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.people),
          label: 'Contactos',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.monetization_on_outlined),
          label: 'Transacciones',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.dashboard),
          label: 'Dashboard',
        ),
      ],
    );
  }

  Widget _buildFab(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.white,
      child: Icon(Icons.add, color: Colors.grey.shade900),
      onPressed: () => _navigateToAddContact(context),
    );
  }

  void _onSearch(BuildContext context) {
    // TODO: implementar búsqueda con showSearch + ContactSearchEvent
  }

  Future<void> _navigateToAddContact(BuildContext context) async {
    final contactBloc = context.read<ContactBloc>();
    final added = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => AddContactScreen(
          usuarioId: ContactsScreen._usuarioId,
          onContactAdded: () => contactBloc.add(
            const ContactFetchEvent(ContactsScreen._usuarioId),
          ),
        ),
      ),
    );
    if (added == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Contacto agregado')),
      );
    }
  }
}

class _ContactCard extends StatelessWidget {
  final ContactModel contact;

  const _ContactCard({required this.contact});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showDetails(context),
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              _buildAvatar(),
              const SizedBox(width: 16),
              Expanded(child: _buildInfo()),
              Icon(Icons.chevron_right, color: Colors.grey.shade700),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          contact.nombre.isNotEmpty ? contact.nombre[0].toUpperCase() : '?',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.blue.shade800,
          ),
        ),
      ),
    );
  }

  Widget _buildInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          contact.nombre,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            Icon(Icons.phone_android, size: 16, color: Colors.grey.shade600),
            const SizedBox(width: 4),
            Text(
              contact.telefono,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade700,
                fontWeight: FontWeight.bold,
              ),
            ),
            if (contact.notas != null && contact.notas!.isNotEmpty) ...[
              const SizedBox(width: 12),
              _buildNotasBadge(),
            ],
          ],
        ),
      ],
    );
  }

  Widget _buildNotasBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        contact.notas!,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 12,
          color: Colors.red.shade700,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  void _showDetails(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => _ContactDetailsSheet(contact: contact),
    );
  }
}

class _ContactDetailsSheet extends StatelessWidget {
  final ContactModel contact;

  const _ContactDetailsSheet({required this.contact});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            contact.nombre,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text('Teléfono: ${contact.telefono}'),
          if (contact.email != null && contact.email!.isNotEmpty)
            Text('Email: ${contact.email}'),
          if (contact.notas != null && contact.notas!.isNotEmpty)
            Text('Notas: ${contact.notas}'),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                icon: const Icon(Icons.message),
                label: const Text('WhatsApp'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  // TODO: abrir WhatsApp con contact.telefono
                  Navigator.pop(context);
                },
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cerrar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
